# MuPiBox-Spiele: je 2 Screenshots

16 Apps, 32 echte Browser-Aufnahmen (800 × 480, WebP).
Die Screenshots wurden mit Chromium aus den jeweiligen HTML-/JS-Anwendungen aufgenommen und sind keine KI-Mockups oder Fotos des MuPiBox-Touchscreens.

| App | Version | Aufnahme 1 | Aufnahme 2 |
|---|---|---|---|
| MuPi Schach | 0.1.5 | 01-start.webp | 02-spiel.webp |
| MuPi Krümelwurm | 0.3.0 | 01-start.webp | 02-spiel.webp |
| MuPi 4er-Reihe | 0.1.5 | 01-start.webp | 02-spiel.webp |
| Klang-Memory | 0.1.3 | 01-start.webp | 02-spiel.webp |
| MuPi Dame-Duell | 0.1.2 | 01-start.webp | 02-spiel.webp |
| MuPi Hnefatafl | 0.1.1 | 01-start.webp | 02-spiel.webp |
| MuPi Mühlenmeister | 0.1.2 | 01-start.webp | 02-spiel.webp |
| MuPi Reversi Arena | 0.1.2 | 01-start.webp | 02-spiel.webp |
| MuPis Rhythm Game | 0.2.1 | 01-start.webp | 02-spiel.webp |
| MuPi Soundquiz | 0.1.2 | 01-start.webp | 02-spiel.webp |
| MuPis BeatBox | 0.1.2 | 01-start.webp | 02-spiel.webp |
| MuPis Würfelrennen | 0.2.8 | 01-start.webp | 02-spiel.webp |
| MuPi Kreuz & Kreis | 0.2.7 | 01-start.webp | 02-spiel.webp |
| MuPi Water Battle | 0.2.5 | 01-start.webp | 02-spiel.webp |
| MuPi Run | 0.3.0 | 01-start.webp | 02-spiel.webp |
| MuPi Klavier | 0.1.2 | 01-start.webp | 02-spiel.webp |
